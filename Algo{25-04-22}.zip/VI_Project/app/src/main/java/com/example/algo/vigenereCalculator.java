package com.example.algo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedList;

public class vigenereCalculator extends AppCompatActivity {

    public static EditText vPlainText;
    public static EditText vKeyText;
    public TextView vEncryptText;
    public TextView vDecryptText;
    public Button vCalculate;
    public Button vSteps;
    public Button vClear;
    public static String Str;
    public static String Keyword;
    public static String key;   //this is for new key
    public static LinkedList<Character> cpLink = new LinkedList<>();
    public static LinkedList<Character> ptLink = new LinkedList<>();
    public static ArrayList<Integer> dl = new ArrayList<>();
    public static ArrayList<String> ctStep = new ArrayList<>();
    public static ArrayList<String> otStep = new ArrayList<>();
    public static int t ;
    public static int clean;
    public String finalCipherText = "";
    public  String finalOriginalText = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vigenere_calculator);

        vPlainText = findViewById(R.id.vigenerePlainText);
        vKeyText = findViewById(R.id.editText_rsa_q);
        vEncryptText = findViewById(R.id.vigenereEncrypt);
        vDecryptText = findViewById(R.id.vigenereDecrypt);
        vCalculate = findViewById(R.id.vigenereCalculateBtn);
        vSteps = findViewById(R.id.vigenereStepBtn);
        vClear = findViewById(R.id.vigenereCleanBtn);

        vCalculate.setOnClickListener(view -> {

            Str = vPlainText.getText().toString();
            Keyword = vKeyText.getText().toString();

            if(Str.equals("") && Keyword.equals("")){
                vPlainText.setError("Text Fields cannot be empty");
                vKeyText.setError("Text Fields cannot be empty");
                t=1;
            }
            else if(vPlainText.getText().toString().equals("")){
                vPlainText.setError("Text Fields cannot be empty");
                t=2;
            }
            else if(vKeyText.getText().toString().equals("")){
                vKeyText.setError("Text Fields cannot be empty");
                t=3;
            }



          else {
             t=0;
                for (int i = 0; i < Str.length(); i++) {
                    if (Str.charAt(i) == ' ') {
                        dl.add(i);
                    }
                }

                // Adding location of space from given string in arraylist
                String a[] = Str.split(" ");


                // Removing space in between the string
                String Str1 = "";
                for (int i = 0; i < a.length; i++) {
                    Str1 += (a[i]);
                }


                String str = LowerToUpper(Str1);
                String keyword = LowerToUpper(Keyword);

                key = generateKey(str, keyword);
                String cipher_text = cipherText(str, key);

//          Adding space to the Cipher text

                char[] cpchar = cipher_text.toCharArray();


                for (char c : cpchar) {
                    cpLink.add(c);
                }

                for (int i = 0; ; i++) {
                    if (i < dl.size()) {

                        cpLink.add(dl.get(i), ' ');
                    } else {
                        break;
                    }

                }



                for (int i = 0; i < cpLink.size(); i++) {
                    finalCipherText += cpLink.get(i);
                }


                vEncryptText.setText(finalCipherText);


                //Adding space to original text
                String original_text = originalText(cipher_text, key);


                char[] ptchar = original_text.toCharArray();


                for (char c : ptchar) {
                    ptLink.add(c);
                }

                for (int i = 0; ; i++) {
                    if (i < dl.size()) {

                        ptLink.add(dl.get(i), ' ');
                    } else {
                        break;
                    }

                }



                for (int i = 0; i < ptLink.size(); i++) {
                    finalOriginalText += ptLink.get(i);
                }


                vDecryptText.setText(finalOriginalText);


            }

          });


            vSteps.setOnClickListener(view -> {

                if(t==1){
                    Toast toast = Toast.makeText(vigenereCalculator.this, "Enter the Text", Toast.LENGTH_SHORT);
                    toast.show();
                }
                else if(t==2){
                    Toast toast = Toast.makeText(vigenereCalculator.this, "Enter the Plain Text", Toast.LENGTH_SHORT);
                    toast.show();
                }

                else if(t==3){
                    Toast toast = Toast.makeText(vigenereCalculator.this, "Enter the Key ", Toast.LENGTH_SHORT);
                    toast.show();
                }
                else {
                    Intent vigenereStepIntent = new Intent(this, vigenereCalculateStep.class);
                    startActivity(vigenereStepIntent);
                }
            });


        vClear.setOnClickListener(view -> {
            vPlainText.getText().clear();
            vKeyText.getText().clear();
            vEncryptText.setText("");
            vDecryptText.setText("");

            finalCipherText = " ";
            finalOriginalText = " ";
            cpLink.clear();
            ptLink.clear();
            dl.clear();
            ctStep.clear();
            otStep.clear();


        });

    }



//    Lower to Upper Case
    static String LowerToUpper(String s)
    {
        StringBuffer str =new StringBuffer(s);
        for(int i = 0; i < s.length(); i++)
        {
            if(Character.isLowerCase(s.charAt(i)))
            {
                str.setCharAt(i, Character.toUpperCase(s.charAt(i)));
            }
        }
        s = str.toString();
        return s;
    }


//    Original Text
    static String originalText(String cipher_text, String key)
    {
        String orig_text="";

        for (int i = 0 ; i < cipher_text.length() &&
                i < key.length(); i++)
        {
            // converting in range 0-25
            int x = (cipher_text.charAt(i) -
                    key.charAt(i) + 26) %26;

            // convert into alphabets(ASCII)
            x += 'A';

            orig_text+=(char)(x);

            //Adding values in array of each iteration for steps

            otStep.add(orig_text);
        }
        return orig_text;
    }

// Generation of new Key if the length of key is less than the plain text length
    static String generateKey(String str, String key)
    {
        int x = str.length();

        for (int i = 0; ; i++)
        {
            if (x == i)
                i = 0;
            if (key.length() == str.length())
                break;
            key+=(key.charAt(i));

        }
        return key;
    }




// Generation of cipher text
    static String cipherText(String str, String key)
    {
        String cipher_text="";

        for (int i = 0; i < str.length(); i++)
        {
            // converting in range 0-25
            int x = (str.charAt(i) + key.charAt(i)) %26;

            // convert into alphabets(ASCII)
            x += 'A';

            cipher_text+=(char)(x);


            //Adding values in array of each iteration for steps

            ctStep.add(cipher_text);
        }
        return cipher_text;
    }
}