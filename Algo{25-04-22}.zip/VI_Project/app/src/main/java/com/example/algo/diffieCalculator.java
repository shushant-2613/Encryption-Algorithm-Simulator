package com.example.algo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigInteger;

public class diffieCalculator extends AppCompatActivity {

    private EditText g;
    private EditText n;
    private EditText x;
    private EditText y;
    private TextView k1edit;
    private TextView k2edit;
    private Button steps;
    public int temp = 0;
    public BigInteger A,B,K1,K2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diffie_calculator);

        g = findViewById(R.id.editText_rsa_p);
        n = findViewById(R.id.editText_rsa_q);
        x = findViewById(R.id.editText_rsa_e);
        y = findViewById(R.id.editText_rsa_plain);
        k1edit = findViewById(R.id.editText_diffie_k1);
        k2edit = findViewById(R.id.editText_diffie_k2);
        Button calculate = findViewById(R.id.diffie_calculate_calculate);
        Button clear = findViewById(R.id.diffie_calculate_clear);


        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(g.getText().toString().equals("") && n.getText().toString().equals("") && x.getText().toString().equals("") && y.getText().toString().equals("")){
                    g.setError("Text Fields cannot be empty");
                    n.setError("Text Fields cannot be empty");
                    x.setError("Text Fields cannot be empty");
                    y.setError("Text Fields cannot be empty");
                    temp++;
                }
                else if(g.getText().toString().equals("")){
                    g.setError("Text Fields cannot be empty");
                    temp++;
                }
                else if(n.getText().toString().equals("")){
                    n.setError("Text Fields cannot be empty");
                    temp++;
                }
                else if(x.getText().toString().equals("")){
                    x.setError("Text Fields cannot be empty");
                    temp++;
                }
                else if(y.getText().toString().equals("")){
                    y.setError("Text Fields cannot be empty");
                    temp++;
                }
                else {

                    A = BigInteger.valueOf(Long.parseLong(g.getText().toString())).modPow(BigInteger.valueOf(Long.parseLong(x.getText().toString())), BigInteger.valueOf(Long.parseLong(n.getText().toString())));
                    B = new BigInteger(g.getText().toString()).modPow(new BigInteger(y.getText().toString()), new BigInteger(n.getText().toString()));
                    K1 = B.modPow(new BigInteger(x.getText().toString()), new BigInteger(n.getText().toString()));
                    K2 = A.modPow(new BigInteger(y.getText().toString()), new BigInteger(n.getText().toString()));

                    k1edit.setText("First Key : "+String.valueOf(K1));
                    k2edit.setText("Second Key : "+String.valueOf(K2));

                    int comparevalue = K1.compareTo(K2);

                    if(comparevalue == 0){
                        Toast.makeText(diffieCalculator.this, "Diffie Hellman Algorithm is verified", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(diffieCalculator.this, "Diffie Hellman Algorithm is not verified", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });



        clear.setOnClickListener(view -> {
            g.getText().clear();
            n.getText().clear();
            x.getText().clear();
            y.getText().clear();

            k1edit.setText("");
            k2edit.setText("");
        });
    }
}